import unittest
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.files import check_submitted_files


class TestHeader(unittest.TestCase):
    # Define how many points it is
    @weight(10)
    # Check if a file with specified filename exists
    def test_file_header(self):
        """Check if header exists"""
        missing_files = check_submitted_files(['HW11p1.py'])
        # Check if files start with a header (comments)
        for filename in missing_files:
            with open(filename, 'r') as file:
                first_line = file.readline().strip()
                self.assertTrue(first_line.startswith('#'), f"File {filename} does not start with a valid header (comments).")

        print('All required files submitted and have valid headers!')

